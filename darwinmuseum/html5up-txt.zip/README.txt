TXT 2.0 by HTML5 UP
html5up.net | @n33co
Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)

A new, fully responsive portfolio/business style website template. I've been experimenting 
with minimalist styles lately and this design is one of many in the works that exemplifies 
this new direction. Hope you enjoy it.

Feedback, bug reports, and comments are not only welcome, but strongly encouraged :)

AJ
n33.co @n33co dribbble.com/n33

Credits:

	Images:
		fotogrph (fotogrph.com)
		Iconify.it (iconify.it)
	
	Other:
		jQuery (jquery.com)
		html5shiv.js (@afarkas @jdalton @jon_neal @rem)
		5grid.js + 5grid-ui.js (n33.co)